window.addEventListener('DOMContentLoaded', () => {
  // ABAS
  function abrirAba(aba) {
    const sensi = document.getElementById("containerSensi");
    const aux = document.getElementById("containerAuxilio");
    const subtitulos = document.querySelectorAll(".subtitulo");

    if (aba === "sensi") {
      sensi.classList.remove("oculto");
      aux.classList.add("oculto");
      subtitulos[0].classList.add("active");
      subtitulos[1].classList.remove("active");
    } else {
      aux.classList.remove("oculto");
      sensi.classList.add("oculto");
      subtitulos[1].classList.add("active");
      subtitulos[0].classList.remove("active");
    }
  }
  window.abrirAba = abrirAba;

  // CANVAS – CHUVA + PARTICULAS
  const canvas = document.getElementById('chuva');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const gotas = [];
  const numGotas = 120;
  for (let i = 0; i < numGotas; i++) {
    gotas.push({x:Math.random()*canvas.width, y:Math.random()*canvas.height, l:Math.random()*10+5, xs:Math.random()*1-0.5, ys:Math.random()*2+2});
  }

  const particulas = [];
  const numParticulas = 150;
  const tamanhoParticula = 3;
  for (let i = 0; i < numParticulas; i++) {
    particulas.push({x:Math.random()*canvas.width, y:Math.random()*canvas.height, ox:0, oy:0, r:tamanhoParticula, alpha:Math.random(), dx:(Math.random()-0.5)*0.5, dy:(Math.random()-0.5)*0.5});
  }
  particulas.forEach(p=>{p.ox=p.x;p.oy=p.y;});

  const mouse={x:canvas.width/2,y:canvas.height/2};
  window.addEventListener('mousemove',(e)=>{mouse.x=e.clientX; mouse.y=e.clientY;});

  function desenharFundo(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle='rgba(198,0,255,0.2)';
    ctx.lineWidth=1.5;
    for(let g of gotas){
      ctx.beginPath();
      ctx.moveTo(g.x,g.y);
      ctx.lineTo(g.x+g.l*g.xs,g.y+g.l*g.ys);
      ctx.stroke();
      g.x+=g.xs; g.y+=g.ys;
      if(g.y>canvas.height){g.x=Math.random()*canvas.width; g.y=-20;}
    }

    for(let p of particulas){
      const dx=mouse.x-p.x;
      const dy=mouse.y-p.y;
      const dist=Math.sqrt(dx*dx+dy*dy);
      if(dist<120){p.x+=dx*0.03;p.y+=dy*0.03;}else{p.x+=(p.ox-p.x)*0.02;p.y+=(p.oy-p.y)*0.02;}
      p.x+=p.dx; p.y+=p.dy;
      p.alpha+=(Math.random()-0.5)*0.02;
      if(p.alpha<=0||p.alpha>=1)p.alpha=Math.random();
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(255,0,255,${p.alpha})`;
      ctx.fill();
    }

    requestAnimationFrame(desenharFundo);
  }
  desenharFundo();

  window.addEventListener('resize',()=>{
    canvas.width=window.innerWidth;
    canvas.height=window.innerHeight;
  });

  // SENSIS – modelos completos
  const modelosPorMarca = {
    "Apple":[
      "iPhone 11","iPhone 11 Pro","iPhone 11 Pro Max",
      "iPhone 12","iPhone 12 Mini","iPhone 12 Pro","iPhone 12 Pro Max",
      "iPhone 13","iPhone 13 Mini","iPhone 13 Pro","iPhone 13 Pro Max",
      "iPhone 14","iPhone 14 Plus","iPhone 14 Pro","iPhone 14 Pro Max",
      "iPhone 15","iPhone 15 Plus","iPhone 15 Pro","iPhone 15 Pro Max",
      "iPhone 16","iPhone 16 Plus","iPhone 16 Pro","iPhone 16 Pro Max",
      "iPhone 17","iPhone 17 Plus","iPhone 17 Pro","iPhone 17 Pro Max"
    ],
    "Samsung":[
      "Galaxy S20","Galaxy S20+","Galaxy S20 Ultra",
      "Galaxy S21","Galaxy S21+","Galaxy S21 Ultra",
      "Galaxy S22","Galaxy S22+","Galaxy S22 Ultra",
      "Galaxy S23","Galaxy S23+","Galaxy S23 Ultra",
      "Galaxy A10","Galaxy A12","Galaxy A20","Galaxy A21","Galaxy A30","Galaxy A31",
      "Galaxy A32","Galaxy A33","Galaxy A34","Galaxy A40","Galaxy A42","Galaxy A50","Galaxy A51","Galaxy A52","Galaxy A53","Galaxy A54",
      "Galaxy A70","Galaxy A71","Galaxy A72","Galaxy A73","Galaxy A74",
      "Galaxy M10","Galaxy M11","Galaxy M20","Galaxy M21","Galaxy M30","Galaxy M31","Galaxy M32","Galaxy M33","Galaxy M34",
      "Galaxy Z Flip","Galaxy Z Fold"
    ],
    "Xiaomi":[
      "Redmi 9","Redmi 9A","Redmi 9C","Redmi 10","Redmi 10C","Redmi 10A",
      "Redmi Note 10","Redmi Note 10 Pro","Redmi Note 11","Redmi Note 11 Pro",
      "Redmi Note 12","Redmi Note 12 Pro","Redmi Note 13","Redmi Note 13 Pro",
      "POCO X3","POCO X3 Pro","POCO X4","POCO X4 Pro","POCO X5","POCO X5 Pro",
      "POCO F3","POCO F4","POCO F5","Mi 11","Mi 11 Lite","Mi 12","Mi 13","Mi 13 Pro"
    ],
    "Motorola":[
      "Moto E20","Moto E22","Moto E32","Moto E40",
      "Moto G20","Moto G21","Moto G30","Moto G31","Moto G32","Moto G40","Moto G41","Moto G50","Moto G51","Moto G52","Moto G60","Moto G71","Moto G72","Moto G73","Moto G200",
      "Edge 20","Edge 20 Pro","Edge 30","Edge 30 Neo","Edge 30 Fusion","Edge 40","Edge 40 Pro","Edge 40 Neo"
    ],
    "Asus":[
      "Zenfone 8","Zenfone 8 Flip","Zenfone 9","Zenfone 10",
      "ROG Phone 5","ROG Phone 5s","ROG Phone 6","ROG Phone 6D","ROG Phone 7","ROG Phone 7 Ultimate"
    ],
    "Realme":[
      "Realme C11","Realme C12","Realme C15","Realme C20","Realme C21","Realme C25","Realme C25s","Realme C30","Realme C31","Realme C32","Realme C33","Realme C35","Realme C67","Realme C67s",
      "Realme 5","Realme 5i","Realme 5s","Realme 6","Realme 6i","Realme 6 Pro","Realme 7","Realme 7i","Realme 7 Pro","Realme 8","Realme 8i","Realme 8 Pro","Realme 9","Realme 9i","Realme 9 Pro","Realme 10","Realme 10 Pro",
      "Realme GT","Realme GT 5","Realme GT 5 Pro"
    ],
    "LG":[
      "LG K22","LG K41","LG K42","LG K52","LG K62",
      "LG Q52","LG Q61","LG Q70","LG Q92",
      "LG G7","LG G8","LG Velvet","LG Wing","LG V50","LG V60","LG V70"
    ],
    "Sony":[
      "Xperia 1 III","Xperia 1 IV","Xperia 1 V",
      "Xperia 5 III","Xperia 5 IV","Xperia 5 V",
      "Xperia 10 III","Xperia 10 IV","Xperia 10 V"
    ],
    "Infinix":[
      "Infinix Hot 10","Infinix Hot 10 Play","Infinix Hot 11","Infinix Hot 11 Play","Infinix Hot 12","Infinix Hot 12 Play",
      "Infinix Smart 5","Infinix Smart 6","Infinix Smart 7","Infinix Smart 8",
      "Infinix Note 10","Infinix Note 10 Pro","Infinix Note 11","Infinix Note 12","Infinix Note 30","Infinix Note 30 Pro",
      "Infinix Zero 5","Infinix Zero 6"
    ]
  };

  const marcaSelect = document.getElementById("marca");
  const modeloSelect = document.getElementById("modelo");
  const resultado = document.getElementById("resultado");

  marcaSelect.addEventListener("change",()=>{
    modeloSelect.innerHTML='<option value="">Selecione</option>';
    const marca=marcaSelect.value;
    if(marca && modelosPorMarca[marca]){
      modelosPorMarca[marca].forEach(modelo=>{
        const opt=document.createElement("option");
        opt.value=modelo; opt.textContent=modelo;
        modeloSelect.appendChild(opt);
      });
    }
    resultado.innerHTML="";
  });

  document.getElementById("gerar").addEventListener("click",()=>{
    const marca=marcaSelect.value;
    const modelo=modeloSelect.value;
    if(!marca||!modelo){alert("Selecione marca e modelo!");return;}

    const geral=Math.floor(Math.random()*200);
    const pontoVermelho=Math.floor(Math.random()*200);
    const mira2x=Math.floor(Math.random()*200);
    const mira4x=Math.floor(Math.random()*200);
    const tamanhoBotao=Math.floor(Math.random()*(60-30+1))+30;

    let infoExtra = "";

    if(marca==="Apple"){
      const cursoMovel=Math.floor(Math.random()*120)+1;
      const ciclos=Math.floor(Math.random()*10)+1;
      infoExtra = `<p><strong>Curso Móvel:</strong> ${cursoMovel}</p>
                   <p><strong>Ciclos:</strong> ${ciclos}</p>`;
    } else {
      const dpi=Math.floor(Math.random()*1000)+1;
      infoExtra = `<p><strong>DPI Recomendada:</strong> ${dpi}</p>`;
    }

    resultado.innerHTML=`
      <p><strong>Marca:</strong> ${marca}</p>
      <p><strong>Modelo:</strong> ${modelo}</p>
      <p><strong>Geral:</strong> ${geral}</p>
      <p><strong>Ponto Vermelho:</strong> ${pontoVermelho}</p>
      <p><strong>Mira 2x:</strong> ${mira2x}</p>
      <p><strong>Mira 4x:</strong> ${mira4x}</p>
      <p><strong>Tamanho do Botão:</strong> ${tamanhoBotao}</p>
      ${infoExtra}
    `;
  });

  // AUXÍLIO
  const injetarBtn=document.getElementById("injetar");
  const barraContainer=document.querySelector(".barra-container");
  const barraProgresso=document.getElementById("barraProgresso");
  const status=document.getElementById("status");
  const porcentagem=document.getElementById("porcentagem");

  injetarBtn.addEventListener("click",()=>{
    barraContainer.classList.remove("oculto");
    barraProgresso.style.width="0%";
    status.textContent="";
    porcentagem.textContent="0%";

    let largura=0;
    const velocidade=1; // quanto maior, mais rápido
    const interval=setInterval(()=>{
      largura+=velocidade;
      if(largura>100) largura=100;
      barraProgresso.style.width=largura+"%";
      porcentagem.textContent=largura+"%";
      if(largura>=100){clearInterval(interval); status.textContent="Injetado ✅";}
    },20);
  });

});